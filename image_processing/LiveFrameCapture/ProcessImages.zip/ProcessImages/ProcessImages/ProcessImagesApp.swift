//
//  ProcessImagesApp.swift
//  ProcessImages
//
//  Created by Dhwani Trivedi on 10/30/22.
//

import SwiftUI

@main
struct ProcessImagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
